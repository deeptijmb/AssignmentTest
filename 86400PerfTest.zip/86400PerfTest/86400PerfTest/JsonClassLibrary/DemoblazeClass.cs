﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _86400PerfTest.JsonClassLibrary
{
    class DemoblazeClass
    {
        public class Item
        {
            public string cat { get; set; }
            public string desc { get; set; }
            public int id { get; set; }
            public string img { get; set; }
            public double price { get; set; }
            public string title { get; set; }
        }

        public class Root
        {
            public List<Item> Items { get; set; }
        }
    }
}
